import { expect, test } from '/Users/krapaud/Documents/Projets/Projets-Pro/Skkup/frontend/node_modules/@playwright/test/index.mjs';
import { mkdir } from 'node:fs/promises';

const profil = {
  id: 'e2e-user', email: 'viewer@example.test', pseudo: 'Viewer e2e', role: 'VIEWER',
  soldePoints: 420, streakActuel: 7, streakMax: 14,
  derniereVisiteAt: '2020-01-01T09:00:00.000Z', createdAt: '2026-10-01T00:00:00.000Z',
};
const annonce = { id: 'announcement-e2e', titre: 'Maintenance prévue', texte: 'Le service revient à 18 h.\nMerci de votre patience.' };

test('Notifications: dialogue rendu, confinement clavier, Escape, fermeture et restitution du focus', async ({ page }) => {
  const evidenceDir = '/private/tmp/skkup-browser-qa-results/notifications-evidence';
  await mkdir(evidenceDir, { recursive: true });
  await page.route('http://localhost:3001/**', async (route) => {
    const { pathname } = new URL(route.request().url());
    let body: unknown = {};
    if (pathname === '/auth/session') body = { authentifie: true, profil };
    else if (pathname === '/me') body = profil;
    else if (pathname === '/me/dashboard/summary') body = {
      profil,
      visionnage: { secondesValidees: 5400, sessions: 3 },
      activite: { ticketsTirage: 4, cartesAGratterDisponibles: 2 },
      transactionsRecentes: [],
    };
    else if (pathname === '/viewer/announcements') body = { items: [annonce], nextCursor: null };
    else if (pathname === '/streams') body = { streams: [] };
    else if (pathname === '/raffles') body = [];
    else if (pathname === '/me/points/history') body = { transactions: [], page: 1, limit: 10, total: 0, totalPages: 1 };
    else if (pathname === '/me/raffle-tickets') body = { tickets: [], page: 1, limit: 10, total: 0, totalPages: 1 };
    else if (pathname === '/me/scratch-cards') body = [];
    else if (pathname === '/me/daily-checkin') body = { pointsCredites: 0, soldePoints: 420, streakActuel: 7, streakMax: 14, carteDebloquee: null };
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) });
  });

  for (const width of [1280, 390, 320]) {
    await page.setViewportSize({ width, height: 850 });
    await page.goto('http://127.0.0.1:3210/dashboard', { waitUntil: 'domcontentloaded' });
    const notifications = page.getByRole('button', { name: 'Notifications' });
    await expect(notifications).toBeVisible();
    await notifications.click();
    const item = page.getByRole('button', { name: annonce.titre });
    await expect(item).toBeVisible();
    await item.click();
    const dialog = page.getByRole('dialog', { name: annonce.titre });
    const close = page.getByRole('button', { name: 'Fermer l’annonce' });
    await expect(dialog).toBeVisible();
    await expect(dialog).toContainText(annonce.texte);
    await page.screenshot({ path: `${evidenceDir}/notifications-${width}-dialog.png`, fullPage: true });
    expect(await page.evaluate(() => document.activeElement?.getAttribute('role'))).toBe('dialog');

    await page.keyboard.press('Tab');
    await expect(close).toBeFocused();
    await page.keyboard.press('Shift+Tab');
    await expect(close).toBeFocused();
    await expect(dialog).toBeVisible();
    expect(await dialog.evaluate((node) => node.contains(document.activeElement))).toBe(true);

    await page.keyboard.press('Escape');
    await expect(dialog).toBeHidden();
    await expect(item).toBeFocused();

    await item.click();
    await expect(dialog).toBeVisible();
    await close.click();
    await expect(dialog).toBeHidden();
    await expect(item).toBeFocused();

    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow, `horizontal overflow at ${width}px`).toBeLessThanOrEqual(1);
  }
});
